function Setthepath()

path(path,'UCM');
path(path,['UCM',filesep,'Aggregation']);
path(path,['UCM',filesep,'Aggregation',filesep,'Appearance']);
path(path,['UCM',filesep,'Aggregation',filesep,'Auxfunctions']);
path(path,['UCM',filesep,'Aggregation',filesep,'Benchmarkcm']);
path(path,['UCM',filesep,'Aggregation',filesep,'Benchmarkev']);
path(path,['UCM',filesep,'Aggregation',filesep,'Intraframesimilarities']);
path(path,['UCM',filesep,'Aggregation',filesep,'Longterm']);
path(path,['UCM',filesep,'Aggregation',filesep,'Metricmerging']);
path(path,['UCM',filesep,'Aggregation',filesep,'Quantitative']);
path(path,['UCM',filesep,'Aggregation',filesep,'Shortterm']);
path(path,['UCM',filesep,'Aggregation',filesep,'Velocitysimilarities']);
path(path,['UCM',filesep,'Auxclustering']);
path(path,['UCM',filesep,'Auxfunctions']);
path(path,['UCM',filesep,'Auxfunctions',filesep,'Auxauxfunctions']);
path(path,['UCM',filesep,'Auxfunctions',filesep,'TVL1']);
path(path,['UCM',filesep,'Auxfunctions',filesep,'VLToolbox']);
path(path,['UCM',filesep,'Clustering']);
path(path,['UCM',filesep,'Fileoperations']);
path(path,['UCM',filesep,'Flow']);
path(path,['UCM',filesep,'Flow',filesep,'Flofiles']);
path(path,['UCM',filesep,'Laplacian']);
path(path,['UCM',filesep,'Otherfunctions']);
path(path,['UCM',filesep,'Otherfunctions',filesep,'Auxwarping']);
path(path,['UCM',filesep,'Segmentation']);
path(path,['UCM',filesep,'Segmentation',filesep,'Addtobenchmark']);
path(path,['UCM',filesep,'Segmentation',filesep,'Benchmark']);
path(path,['UCM',filesep,'Segmentation',filesep,'Lib']);

