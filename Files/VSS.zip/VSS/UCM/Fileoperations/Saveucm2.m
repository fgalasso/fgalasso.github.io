function Saveucm2(filename,ucm2)
%The function is used to save the variable with the ucm2 name

save(filename,'ucm2');

